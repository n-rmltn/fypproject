<!-- Footer -->
<footer class="border-top py-5 mt-4">
<div class="container-fluid">
    <div
    class="d-flex justify-content-between align-items-center flex-column flex-lg-row"
    >
    <p class="small m-0 text-center text-lg-start text-muted m-auto">
        &copy; 2022 KBDmy Co. All Rights Reserved. Created by Norm
    </p>
    </div>
</div>
</footer>
<!-- / Footer-->
